package com.example.websocketcallback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsocketCallbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
